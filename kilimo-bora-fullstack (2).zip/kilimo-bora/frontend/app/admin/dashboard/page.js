'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { authApi, adminApi, clearAdminToken } from '../../../lib/api';

const TABS = ['Crops', 'Market Prices', 'Pests', 'Alerts', 'Farmer Questions'];

export default function AdminDashboard() {
  const router = useRouter();
  const [admin, setAdmin] = useState(null);
  const [checking, setChecking] = useState(true);
  const [tab, setTab] = useState('Crops');

  useEffect(() => {
    authApi.me()
      .then(({ admin }) => setAdmin(admin))
      .catch(() => {
        clearAdminToken();
        router.replace('/admin/login');
      })
      .finally(() => setChecking(false));
  }, [router]);

  function handleLogout() {
    clearAdminToken();
    router.replace('/admin/login');
  }

  if (checking) return <div style={styles.centered}>Checking session…</div>;
  if (!admin) return null; // redirecting

  return (
    <div style={styles.page}>
      <header style={styles.header}>
        <div>
          <h1 style={styles.title}>Kilimo Bora Admin</h1>
          <p style={styles.subtitle}>{admin.name} · {admin.role}</p>
        </div>
        <button onClick={handleLogout} style={styles.logoutBtn}>Log out</button>
      </header>

      <nav style={styles.tabs}>
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            style={{ ...styles.tabBtn, ...(tab === t ? styles.tabBtnActive : {}) }}
          >
            {t}
          </button>
        ))}
      </nav>

      <main style={styles.main}>
        {tab === 'Crops' && <CropsPanel />}
        {tab === 'Market Prices' && <PricesPanel />}
        {tab === 'Pests' && <PestsPanel />}
        {tab === 'Alerts' && <AlertsPanel />}
        {tab === 'Farmer Questions' && <QuestionsPanel />}
      </main>
    </div>
  );
}

// ---------------- Crops ----------------
function CropsPanel() {
  const [crops, setCrops] = useState([]);
  const [form, setForm] = useState({ name_en: '', name_sw: '', name_ek: '', season: '', advice_en: '', advice_sw: '', advice_ek: '' });
  const [error, setError] = useState('');

  const load = () => adminApi.listCrops().then((d) => setCrops(d.crops)).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  async function handleAdd(e) {
    e.preventDefault();
    setError('');
    try {
      await adminApi.createCrop(form);
      setForm({ name_en: '', name_sw: '', name_ek: '', season: '', advice_en: '', advice_sw: '', advice_ek: '' });
      load();
    } catch (err) { setError(err.message); }
  }

  async function handleDelete(id) {
    if (!confirm('Delete this crop entry?')) return;
    await adminApi.deleteCrop(id);
    load();
  }

  return (
    <div>
      <h2 style={styles.panelTitle}>Crop Advisory</h2>
      <form onSubmit={handleAdd} style={styles.form}>
        <div style={styles.formRow}>
          <input style={styles.input} placeholder="Name (English)" value={form.name_en} onChange={(e) => setForm({ ...form, name_en: e.target.value })} required />
          <input style={styles.input} placeholder="Name (Kiswahili)" value={form.name_sw} onChange={(e) => setForm({ ...form, name_sw: e.target.value })} required />
          <input style={styles.input} placeholder="Name (Ekegusii)" value={form.name_ek} onChange={(e) => setForm({ ...form, name_ek: e.target.value })} required />
        </div>
        <input style={styles.input} placeholder="Season" value={form.season} onChange={(e) => setForm({ ...form, season: e.target.value })} />
        <textarea style={styles.textarea} placeholder="Advice (English)" value={form.advice_en} onChange={(e) => setForm({ ...form, advice_en: e.target.value })} />
        {error && <div style={styles.error}>{error}</div>}
        <button style={styles.button} type="submit">Add Crop</button>
      </form>

      <ul style={styles.list}>
        {crops.map((c) => (
          <li key={c.id} style={styles.listItem}>
            <strong>{c.name_en}</strong> ({c.name_sw} / {c.name_ek}) — {c.season || 'No season set'}
            <button onClick={() => handleDelete(c.id)} style={styles.deleteBtn}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ---------------- Prices ----------------
function PricesPanel() {
  const [prices, setPrices] = useState([]);
  const [form, setForm] = useState({ crop_name: '', market: '', price: '', unit: 'per kg' });
  const [error, setError] = useState('');

  const load = () => adminApi.listPrices().then((d) => setPrices(d.prices)).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  async function handleAdd(e) {
    e.preventDefault();
    setError('');
    try {
      await adminApi.createPrice({ ...form, price: parseFloat(form.price) });
      setForm({ crop_name: '', market: '', price: '', unit: 'per kg' });
      load();
    } catch (err) { setError(err.message); }
  }

  return (
    <div>
      <h2 style={styles.panelTitle}>Market Prices</h2>
      <form onSubmit={handleAdd} style={styles.form}>
        <div style={styles.formRow}>
          <input style={styles.input} placeholder="Crop name" value={form.crop_name} onChange={(e) => setForm({ ...form, crop_name: e.target.value })} required />
          <input style={styles.input} placeholder="Market" value={form.market} onChange={(e) => setForm({ ...form, market: e.target.value })} required />
          <input style={styles.input} type="number" step="0.01" placeholder="Price (KES)" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} required />
        </div>
        {error && <div style={styles.error}>{error}</div>}
        <button style={styles.button} type="submit">Add Price</button>
      </form>

      <ul style={styles.list}>
        {prices.map((p) => (
          <li key={p.id} style={styles.listItem}>
            {p.crop_name} — KES {p.price} {p.unit} @ {p.market} ({new Date(p.price_date).toLocaleDateString()})
            <button onClick={async () => { await adminApi.deletePrice(p.id); load(); }} style={styles.deleteBtn}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ---------------- Pests ----------------
function PestsPanel() {
  const [pests, setPests] = useState([]);
  const [form, setForm] = useState({ name: '', crop: '', severity: 'Wastani', symptoms: '', treatment: '', prevention: '' });
  const [error, setError] = useState('');

  const load = () => adminApi.listPests().then((d) => setPests(d.pests)).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  async function handleAdd(e) {
    e.preventDefault();
    setError('');
    try {
      await adminApi.createPest(form);
      setForm({ name: '', crop: '', severity: 'Wastani', symptoms: '', treatment: '', prevention: '' });
      load();
    } catch (err) { setError(err.message); }
  }

  return (
    <div>
      <h2 style={styles.panelTitle}>Pests & Diseases</h2>
      <form onSubmit={handleAdd} style={styles.form}>
        <div style={styles.formRow}>
          <input style={styles.input} placeholder="Pest/disease name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          <input style={styles.input} placeholder="Crop affected" value={form.crop} onChange={(e) => setForm({ ...form, crop: e.target.value })} required />
          <select style={styles.input} value={form.severity} onChange={(e) => setForm({ ...form, severity: e.target.value })}>
            <option>Wastani</option>
            <option>Hatari Kubwa</option>
            <option>Hatari Sana</option>
          </select>
        </div>
        <textarea style={styles.textarea} placeholder="Symptoms" value={form.symptoms} onChange={(e) => setForm({ ...form, symptoms: e.target.value })} required />
        <textarea style={styles.textarea} placeholder="Treatment" value={form.treatment} onChange={(e) => setForm({ ...form, treatment: e.target.value })} required />
        {error && <div style={styles.error}>{error}</div>}
        <button style={styles.button} type="submit">Add Pest Entry</button>
      </form>

      <ul style={styles.list}>
        {pests.map((p) => (
          <li key={p.id} style={styles.listItem}>
            <strong>{p.name}</strong> ({p.crop}) — {p.severity}
            <button onClick={async () => { await adminApi.deletePest(p.id); load(); }} style={styles.deleteBtn}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ---------------- Alerts ----------------
function AlertsPanel() {
  const [alerts, setAlerts] = useState([]);
  const [form, setForm] = useState({ message: '', severity: 'info' });
  const [error, setError] = useState('');

  const load = () => adminApi.listAlerts().then((d) => setAlerts(d.alerts)).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  async function handleAdd(e) {
    e.preventDefault();
    setError('');
    try {
      await adminApi.createAlert(form);
      setForm({ message: '', severity: 'info' });
      load();
    } catch (err) { setError(err.message); }
  }

  return (
    <div>
      <h2 style={styles.panelTitle}>Weather Alerts</h2>
      <form onSubmit={handleAdd} style={styles.form}>
        <textarea style={styles.textarea} placeholder="Alert message" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} required />
        <select style={styles.input} value={form.severity} onChange={(e) => setForm({ ...form, severity: e.target.value })}>
          <option value="info">Info</option>
          <option value="warning">Warning</option>
          <option value="danger">Danger</option>
        </select>
        {error && <div style={styles.error}>{error}</div>}
        <button style={styles.button} type="submit">Post Alert</button>
      </form>

      <ul style={styles.list}>
        {alerts.map((a) => (
          <li key={a.id} style={styles.listItem}>
            [{a.severity}] {a.message} {!a.is_active && '(inactive)'}
            {a.is_active && (
              <button onClick={async () => { await adminApi.deactivateAlert(a.id); load(); }} style={styles.deleteBtn}>Deactivate</button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

// ---------------- Farmer Questions ----------------
function QuestionsPanel() {
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [error, setError] = useState('');

  const load = () => adminApi.listQuestions('pending').then((d) => setQuestions(d.questions)).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  async function handleAnswer(id) {
    const answer = answers[id];
    if (!answer) return;
    await adminApi.answerQuestion(id, answer);
    load();
  }

  return (
    <div>
      <h2 style={styles.panelTitle}>Pending Farmer Questions</h2>
      {error && <div style={styles.error}>{error}</div>}
      <ul style={styles.list}>
        {questions.length === 0 && <li style={styles.listItem}>No pending questions.</li>}
        {questions.map((q) => (
          <li key={q.id} style={{ ...styles.listItem, flexDirection: 'column', alignItems: 'stretch' }}>
            <div><strong>{q.farmer_phone || 'Anonymous'}:</strong> {q.question}</div>
            <textarea
              style={styles.textarea}
              placeholder="Type your answer…"
              value={answers[q.id] || ''}
              onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
            />
            <button style={{ ...styles.button, alignSelf: 'flex-start' }} onClick={() => handleAnswer(q.id)}>Send Answer</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

const styles = {
  centered: { display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', color: '#666' },
  page: { minHeight: '100vh', background: '#f5f5f3' },
  header: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    background: '#1a5c2e', color: '#fff', padding: '16px 24px',
  },
  title: { fontSize: 18, fontWeight: 700 },
  subtitle: { fontSize: 12, opacity: 0.8, marginTop: 2 },
  logoutBtn: { background: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.4)', color: '#fff', borderRadius: 8, padding: '8px 14px', fontSize: 13 },
  tabs: { display: 'flex', gap: 4, padding: '12px 24px 0', flexWrap: 'wrap', background: '#fff', borderBottom: '1px solid #eee' },
  tabBtn: { border: 'none', background: 'transparent', padding: '10px 14px', fontSize: 13, fontWeight: 600, color: '#666', borderBottom: '2px solid transparent' },
  tabBtnActive: { color: '#1a5c2e', borderBottom: '2px solid #1a5c2e' },
  main: { padding: 24, maxWidth: 900, margin: '0 auto' },
  panelTitle: { fontSize: 18, fontWeight: 700, marginBottom: 16, color: '#1a5c2e' },
  form: { display: 'flex', flexDirection: 'column', gap: 10, background: '#fff', padding: 16, borderRadius: 12, border: '1px solid #eee', marginBottom: 20 },
  formRow: { display: 'flex', gap: 10, flexWrap: 'wrap' },
  input: { flex: 1, minWidth: 140, padding: '9px 12px', borderRadius: 8, border: '1px solid rgba(0,0,0,0.15)', fontSize: 13 },
  textarea: { padding: '9px 12px', borderRadius: 8, border: '1px solid rgba(0,0,0,0.15)', fontSize: 13, minHeight: 60, resize: 'vertical' },
  button: { background: '#1a5c2e', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 18px', fontSize: 13, fontWeight: 600 },
  error: { background: '#fde8e8', color: '#a32d2d', fontSize: 12, padding: '8px 12px', borderRadius: 8 },
  list: { listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 8 },
  listItem: { background: '#fff', border: '1px solid #eee', borderRadius: 10, padding: '10px 14px', fontSize: 13, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 },
  deleteBtn: { background: '#fde8e8', color: '#a32d2d', border: 'none', borderRadius: 6, padding: '6px 10px', fontSize: 12 },
};
