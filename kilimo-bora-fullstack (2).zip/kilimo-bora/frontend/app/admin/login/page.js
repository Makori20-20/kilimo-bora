'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { authApi, setAdminToken } from '../../../lib/api';

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { token } = await authApi.login(email.trim(), password);
      setAdminToken(token);
      router.push('/admin/dashboard');
    } catch (err) {
      setError(err.message || 'Login failed. Check your credentials and try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.header}>
          <h1 style={styles.title}>Kilimo Bora 🌿</h1>
          <p style={styles.subtitle}>Admin Portal · Kisii County</p>
        </div>

        <form onSubmit={handleSubmit} style={styles.form}>
          <label style={styles.label}>
            Email
            <input
              type="email"
              required
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={styles.input}
              placeholder="admin@kilimobora.co.ke"
            />
          </label>

          <label style={styles.label}>
            Password
            <input
              type="password"
              required
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={styles.input}
              placeholder="••••••••"
            />
          </label>

          {error && <div style={styles.error}>{error}</div>}

          <button type="submit" disabled={loading} style={styles.button}>
            {loading ? 'Signing in…' : 'Sign In'}
          </button>
        </form>

        <p style={styles.footnote}>
          Authorized personnel only. All login attempts are logged.
        </p>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: '#d0e8d8',
    padding: 16,
  },
  card: {
    width: '100%',
    maxWidth: 380,
    background: '#fff',
    borderRadius: 16,
    boxShadow: '0 8px 32px rgba(0,0,0,0.18)',
    padding: '32px 28px',
  },
  header: { textAlign: 'center', marginBottom: 24 },
  title: { fontSize: 24, fontWeight: 700, color: '#1a5c2e' },
  subtitle: { fontSize: 13, color: '#2d7a44', marginTop: 4 },
  form: { display: 'flex', flexDirection: 'column', gap: 14 },
  label: { fontSize: 13, fontWeight: 600, color: '#333', display: 'flex', flexDirection: 'column', gap: 6 },
  input: {
    padding: '10px 12px',
    borderRadius: 8,
    border: '1px solid rgba(0,0,0,0.15)',
    fontSize: 14,
    fontWeight: 400,
  },
  error: {
    background: '#fde8e8',
    color: '#a32d2d',
    fontSize: 13,
    padding: '8px 12px',
    borderRadius: 8,
  },
  button: {
    marginTop: 6,
    background: '#1a5c2e',
    color: '#fff',
    border: 'none',
    borderRadius: 8,
    padding: '12px 0',
    fontSize: 14,
    fontWeight: 600,
  },
  footnote: { fontSize: 11, color: '#999', textAlign: 'center', marginTop: 20 },
};
