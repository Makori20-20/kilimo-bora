'use client';

import { useEffect, useState } from 'react';
import { publicApi } from '../lib/api';

const LANG = {
  sw: { greeting: 'Habari, Mkulima', services: 'Huduma', crops: 'Ushauri wa Mazao', prices: 'Bei za Soko', pests: 'Magonjwa & Wadudu', expert: 'Uliza Mtaalamu' },
  en: { greeting: 'Hello, Farmer', services: 'Services', crops: 'Crop Advisory', prices: 'Market Prices', pests: 'Pests & Disease', expert: 'Ask an Expert' },
  ek: { greeting: 'Bwatero, Omolimi', services: 'Seera', crops: 'Obwasari bwa Ebiryo', prices: 'Emigaso ya Masoko', pests: 'Ebikweri & Endwara', expert: 'Oria Omogaka' },
};

export default function Home() {
  const [lang, setLang] = useState('sw');
  const [screen, setScreen] = useState('home');
  const [crops, setCrops] = useState([]);
  const [prices, setPrices] = useState([]);
  const [pests, setPests] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [question, setQuestion] = useState('');
  const [phone, setPhone] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const t = LANG[lang];

  useEffect(() => {
    Promise.all([publicApi.getCrops(), publicApi.getPrices(), publicApi.getPests(), publicApi.getAlerts()])
      .then(([c, p, pe, a]) => {
        setCrops(c.crops); setPrices(p.prices); setPests(pe.pests); setAlerts(a.alerts);
      })
      .catch((e) => setError(e.message));
  }, []);

  async function handleAsk(e) {
    e.preventDefault();
    if (!question.trim()) return;
    try {
      await publicApi.askQuestion(phone, question);
      setQuestion('');
      setSent(true);
      setTimeout(() => setSent(false), 4000);
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div style={styles.wrap}>
      <div style={styles.phone}>
        <div style={styles.appHeader}>
          {screen !== 'home' && <div onClick={() => setScreen('home')} style={styles.back}>← {lang === 'en' ? 'Home' : 'Nyumbani'}</div>}
          <div style={styles.greeting}>{t.greeting}</div>
          <div style={styles.headerRow}>
            <h1 style={styles.h1}>Kilimo Bora 🌿</h1>
            <div style={styles.langPills}>
              {['sw', 'en', 'ek'].map((code) => (
                <span key={code} onClick={() => setLang(code)} style={{ ...styles.pill, ...(lang === code ? styles.pillActive : {}) }}>
                  {code.toUpperCase()}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div style={styles.scroll}>
          {error && <div style={styles.errorBanner}>{error}</div>}

          {screen === 'home' && (
            <>
              {alerts.length > 0 && (
                <div style={styles.weatherStrip}>
                  {alerts.map((a) => (
                    <div key={a.id} style={styles.alertLine}>⚠️ {a.message}</div>
                  ))}
                </div>
              )}
              <div style={styles.sectionLabel}>{t.services}</div>
              <div style={styles.grid}>
                <FeatureCard emoji="🌱" title={t.crops} onClick={() => setScreen('crops')} />
                <FeatureCard emoji="💰" title={t.prices} onClick={() => setScreen('prices')} />
                <FeatureCard emoji="🐛" title={t.pests} onClick={() => setScreen('pests')} />
                <FeatureCard emoji="💬" title={t.expert} onClick={() => setScreen('expert')} />
              </div>
            </>
          )}

          {screen === 'crops' && (
            <List items={crops} render={(c) => (
              <div key={c.id} style={styles.card}>
                <strong>{lang === 'en' ? c.name_en : lang === 'ek' ? c.name_ek : c.name_sw}</strong>
                {c.season && <div style={styles.muted}>{c.season}</div>}
                <div style={styles.body}>{lang === 'en' ? c.advice_en : lang === 'ek' ? c.advice_ek : c.advice_sw}</div>
              </div>
            )} empty="No crop advisories published yet." />
          )}

          {screen === 'prices' && (
            <List items={prices} render={(p) => (
              <div key={p.id} style={styles.card}>
                <strong>{p.crop_name}</strong> — KES {p.price} {p.unit}
                <div style={styles.muted}>{p.market} · {new Date(p.price_date).toLocaleDateString()}</div>
              </div>
            )} empty="No market prices posted yet." />
          )}

          {screen === 'pests' && (
            <List items={pests} render={(p) => (
              <div key={p.id} style={styles.card}>
                <strong>{p.name}</strong> ({p.crop}) — {p.severity}
                <div style={styles.body}><strong>Symptoms:</strong> {p.symptoms}</div>
                <div style={styles.body}><strong>Treatment:</strong> {p.treatment}</div>
              </div>
            )} empty="No pest/disease entries yet." />
          )}

          {screen === 'expert' && (
            <div style={{ padding: 14 }}>
              <form onSubmit={handleAsk} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <input style={styles.input} placeholder="Phone (optional)" value={phone} onChange={(e) => setPhone(e.target.value)} />
                <textarea style={styles.textarea} placeholder="Andika swali lako..." value={question} onChange={(e) => setQuestion(e.target.value)} required />
                <button type="submit" style={styles.button}>Send / Tuma</button>
              </form>
              {sent && <div style={styles.sentMsg}>✅ Swali limetumwa. Extension officer atakujibu hivi karibuni.</div>}
            </div>
          )}
        </div>

        <div style={styles.navBar}>
          <NavBtn label="🏠" onClick={() => setScreen('home')} active={screen === 'home'} />
          <NavBtn label="💰" onClick={() => setScreen('prices')} active={screen === 'prices'} />
          <NavBtn label="🌱" onClick={() => setScreen('crops')} active={screen === 'crops'} />
          <NavBtn label="🐛" onClick={() => setScreen('pests')} active={screen === 'pests'} />
          <NavBtn label="💬" onClick={() => setScreen('expert')} active={screen === 'expert'} />
        </div>
      </div>

      <p style={styles.footer}>Kilimo Bora · Kisii County, Kenya · 2026</p>
    </div>
  );
}

function FeatureCard({ emoji, title, onClick }) {
  return (
    <div onClick={onClick} style={styles.featureCard}>
      <div style={styles.featureIcon}>{emoji}</div>
      <div style={styles.featureTitle}>{title}</div>
    </div>
  );
}

function NavBtn({ label, onClick, active }) {
  return <div onClick={onClick} style={{ ...styles.navBtn, ...(active ? styles.navBtnActive : {}) }}>{label}</div>;
}

function List({ items, render, empty }) {
  if (!items.length) return <div style={{ padding: 20, textAlign: 'center', color: '#999', fontSize: 13 }}>{empty}</div>;
  return <div style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>{items.map(render)}</div>;
}

const styles = {
  wrap: { minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '24px 12px 48px', background: '#d0e8d8' },
  phone: { width: '100%', maxWidth: 390, background: '#fff', borderRadius: 24, overflow: 'hidden', boxShadow: '0 8px 32px rgba(0,0,0,0.18)' },
  appHeader: { background: '#1a5c2e', padding: '14px 16px', color: '#fff' },
  back: { fontSize: 12, opacity: 0.8, cursor: 'pointer', marginBottom: 6 },
  greeting: { fontSize: 11, opacity: 0.75 },
  headerRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 },
  h1: { fontSize: 18, fontWeight: 700 },
  langPills: { display: 'flex', gap: 6 },
  pill: { fontSize: 10, padding: '4px 9px', borderRadius: 99, border: '1px solid rgba(255,255,255,0.35)', cursor: 'pointer', opacity: 0.8 },
  pillActive: { background: 'rgba(255,255,255,0.22)', opacity: 1 },
  scroll: { maxHeight: 480, overflowY: 'auto' },
  errorBanner: { background: '#fde8e8', color: '#a32d2d', fontSize: 12, padding: 10, margin: 12, borderRadius: 8 },
  weatherStrip: { background: '#2d7a44', margin: 12, borderRadius: 12, padding: 12, color: '#fff' },
  alertLine: { fontSize: 12, marginBottom: 4 },
  sectionLabel: { fontSize: 10, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase', color: '#666', padding: '12px 14px 6px' },
  grid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, padding: '0 12px 12px' },
  featureCard: { background: '#f5f5f3', borderRadius: 12, padding: 14, cursor: 'pointer' },
  featureIcon: { fontSize: 22, marginBottom: 8 },
  featureTitle: { fontSize: 13, fontWeight: 600 },
  card: { background: '#fff', border: '1px solid #eee', borderRadius: 12, padding: 12, fontSize: 13 },
  muted: { fontSize: 11, color: '#888', marginTop: 2 },
  body: { fontSize: 12, marginTop: 6, lineHeight: 1.4 },
  input: { padding: '10px 12px', borderRadius: 8, border: '1px solid rgba(0,0,0,0.15)', fontSize: 13 },
  textarea: { padding: '10px 12px', borderRadius: 8, border: '1px solid rgba(0,0,0,0.15)', fontSize: 13, minHeight: 80 },
  button: { background: '#1a5c2e', color: '#fff', border: 'none', borderRadius: 8, padding: '11px 0', fontWeight: 600, fontSize: 13 },
  sentMsg: { marginTop: 12, fontSize: 12, color: '#1a5c2e' },
  navBar: { display: 'flex', borderTop: '1px solid #eee' },
  navBtn: { flex: 1, textAlign: 'center', padding: '10px 0', fontSize: 18, cursor: 'pointer', opacity: 0.5 },
  navBtnActive: { opacity: 1, background: '#f5f5f3' },
  footer: { fontSize: 11, color: '#3a6b48', marginTop: 16, textAlign: 'center' },
};
