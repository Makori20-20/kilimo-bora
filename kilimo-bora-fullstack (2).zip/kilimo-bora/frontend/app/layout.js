import './globals.css';

export const metadata = {
  title: 'Kilimo Bora — Agricultural Information Hub · Kisii',
  description: 'Agricultural information hub for smallholder farmers in Kisii County',
};

export default function RootLayout({ children }) {
  return (
    <html lang="sw">
      <body>{children}</body>
    </html>
  );
}
