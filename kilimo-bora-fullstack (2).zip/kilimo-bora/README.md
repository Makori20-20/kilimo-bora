# Kilimo Bora — Agricultural Information Hub (Kisii County)

Full-stack rebuild of your Kilimo Bora mockup, with a real backend, PostgreSQL
database, and **admin authentication**. The farmer-facing UI now pulls live
data instead of hardcoded fake content, and everything shown to farmers is
managed through a protected admin dashboard.

Verified end-to-end during development: login, JWT-protected routes, rate
limiting, and the admin → public data flow were all tested against a real
PostgreSQL database before delivery.

## Stack

- **Frontend:** Next.js 16 (App Router), plain JS, no external UI libraries
- **Backend:** Node.js + Express, PostgreSQL (via `pg`)
- **Auth:** JWT (bcrypt-hashed passwords, 12 salt rounds), role-based (`admin` / `superadmin`)

## Project structure

```
kilimo-bora/
├── backend/
│   ├── src/
│   │   ├── index.js              # Express app entrypoint
│   │   ├── schema.sql            # Full DB schema
│   │   ├── config/db.js          # PostgreSQL pool
│   │   ├── middleware/
│   │   │   ├── authMiddleware.js # JWT verification + role checks
│   │   │   └── rateLimiter.js    # Login brute-force protection
│   │   ├── controllers/
│   │   │   ├── authController.js    # Login, /me, change password, create admin
│   │   │   └── adminController.js   # CRUD for crops/prices/pests/alerts/questions
│   │   ├── routes/
│   │   │   ├── authRoutes.js
│   │   │   ├── adminRoutes.js    # All routes require a valid admin JWT
│   │   │   └── publicRoutes.js   # Read-only, no auth — consumed by farmer UI
│   │   └── utils/
│   │       ├── migrate.js        # Applies schema.sql
│   │       ├── seedAdmin.js      # Creates the first admin account
│   │       └── asyncHandler.js
│   └── .env.example
└── frontend/
    ├── app/
    │   ├── page.js                # Farmer-facing hub (EN/SW/EK)
    │   └── admin/
    │       ├── login/page.js      # Admin login screen
    │       └── dashboard/page.js  # Protected dashboard (crops, prices, pests, alerts, Q&A)
    ├── lib/api.js                 # Fetch wrapper, attaches JWT to admin requests
    └── .env.local.example
```

## How the admin authentication works

1. An admin logs in at `/admin/login` with email + password.
2. The backend checks the password with `bcrypt.compare`, and on success signs
   a JWT (`sub`, `email`, `role`) valid for 8 hours.
3. The token is stored in `localStorage` on the frontend and attached as
   `Authorization: Bearer <token>` on every admin request.
4. `requireAdmin` middleware verifies the JWT **and** re-checks the database,
   so a deactivated admin is locked out immediately even with a valid token.
5. `requireSuperAdmin` further restricts sensitive routes (like creating new
   admin accounts) to the `superadmin` role.
6. Every admin action (login, create/update/delete, password change) is
   written to `admin_audit_log`.
7. Login attempts are rate-limited (8 per 15 minutes) to slow brute-force attacks.
8. Content admins publish (crops, prices, pest alerts, weather alerts) becomes
   visible on the public, unauthenticated endpoints the farmer app reads from.

## Local setup

### 1. Database
```bash
cd backend
cp .env.example .env
# edit .env: set DATABASE_URL, JWT_SECRET, and SEED_ADMIN_* values
npm install
npm run migrate       # creates all tables
npm run seed:admin    # creates your first admin login
```

### 2. Backend API
```bash
npm run dev            # http://localhost:4000
```

### 3. Frontend
```bash
cd ../frontend
cp .env.local.example .env.local   # points to http://localhost:4000/api
npm install
npm run dev             # http://localhost:3000
```

Visit `http://localhost:3000` for the farmer hub, and
`http://localhost:3000/admin/login` to sign in with the account you seeded.

## Deployment (free tiers, matches your existing setup)

- **Database → [Neon](https://neon.tech):** create a project, copy the pooled
  connection string into `DATABASE_URL` (keep `?sslmode=require`).
- **Backend → [Render](https://render.com):** new Web Service, root directory
  `backend`, build command `npm install`, start command `npm start`. Add all
  `.env` vars in Render's dashboard, then run `npm run migrate` and
  `npm run seed:admin` once via Render's shell (or locally against the Neon URL).
- **Frontend → [Vercel](https://vercel.com):** import the `frontend` folder,
  set `NEXT_PUBLIC_API_URL` to your deployed Render API URL
  (e.g. `https://kilimo-bora-api.onrender.com/api`).
- Update `FRONTEND_URL` in the backend's env to your live Vercel URL, so CORS
  allows it.

## Security notes for your report

- Passwords are never stored or logged in plaintext; only bcrypt hashes.
- Login errors are intentionally generic ("Invalid email or password") so
  failed attempts can't be used to discover which emails are registered admins.
- The JWT secret and DB credentials live only in `.env` (not committed —
  add `.env` to `.gitignore` if you push this to GitHub).
- Change `SEED_ADMIN_PASSWORD` immediately after first login in production.
