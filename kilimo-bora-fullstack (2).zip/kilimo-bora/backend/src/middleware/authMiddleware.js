const jwt = require('jsonwebtoken');
const pool = require('../config/db');

// Verifies the JWT in the Authorization header and attaches the admin to req.admin.
// Also re-checks the DB so a deactivated admin is rejected immediately, even with a valid token.
async function requireAdmin(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Authentication required. No token provided.' });
  }

  let payload;
  try {
    payload = jwt.verify(token, process.env.JWT_SECRET);
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Session expired. Please log in again.' });
    }
    return res.status(401).json({ error: 'Invalid token.' });
  }

  try {
    const result = await pool.query(
      'SELECT id, name, email, role, is_active FROM admins WHERE id = $1',
      [payload.sub]
    );
    const admin = result.rows[0];
    if (!admin || !admin.is_active) {
      return res.status(401).json({ error: 'Account not found or deactivated.' });
    }
    req.admin = admin;
    next();
  } catch (err) {
    console.error('Auth middleware DB error:', err.message);
    return res.status(500).json({ error: 'Internal server error.' });
  }
}

// Restricts a route to superadmins only (e.g. managing other admin accounts).
function requireSuperAdmin(req, res, next) {
  if (!req.admin || req.admin.role !== 'superadmin') {
    return res.status(403).json({ error: 'Superadmin privileges required.' });
  }
  next();
}

module.exports = { requireAdmin, requireSuperAdmin };
