const rateLimit = require('express-rate-limit');

// Slows down brute-force attempts against the admin login endpoint specifically.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 8,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many login attempts. Please try again in 15 minutes.' },
});

module.exports = { loginLimiter };
