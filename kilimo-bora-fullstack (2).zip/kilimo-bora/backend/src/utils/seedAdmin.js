// Creates the first admin account from env vars. Safe to re-run (skips on conflict).
// Usage: npm run seed:admin
require('dotenv').config();
const bcrypt = require('bcryptjs');
const pool = require('../config/db');

async function seed() {
  const name = process.env.SEED_ADMIN_NAME;
  const email = process.env.SEED_ADMIN_EMAIL;
  const password = process.env.SEED_ADMIN_PASSWORD;

  if (!name || !email || !password) {
    console.error('SEED_ADMIN_NAME, SEED_ADMIN_EMAIL, SEED_ADMIN_PASSWORD must be set in .env');
    process.exit(1);
  }
  if (password.length < 8) {
    console.error('SEED_ADMIN_PASSWORD must be at least 8 characters.');
    process.exit(1);
  }

  const password_hash = await bcrypt.hash(password, 12);

  try {
    const existing = await pool.query('SELECT id FROM admins WHERE email = $1', [email]);
    if (existing.rows.length > 0) {
      console.log(`Admin with email ${email} already exists. Skipping.`);
      return;
    }
    await pool.query(
      `INSERT INTO admins (name, email, password_hash, role) VALUES ($1, $2, $3, 'superadmin')`,
      [name, email, password_hash]
    );
    console.log(`Admin account created: ${email}`);
    console.log('Log in and change the password if this was a default value.');
  } catch (err) {
    console.error('Seeding failed:', err.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

seed();
