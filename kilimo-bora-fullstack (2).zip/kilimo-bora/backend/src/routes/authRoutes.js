const express = require('express');
const router = express.Router();
const { adminLogin, getMe, changePassword, createAdmin } = require('../controllers/authController');
const { requireAdmin, requireSuperAdmin } = require('../middleware/authMiddleware');
const { loginLimiter } = require('../middleware/rateLimiter');
const asyncHandler = require('../utils/asyncHandler');

router.post('/admin/login', loginLimiter, asyncHandler(adminLogin));
router.get('/admin/me', requireAdmin, asyncHandler(getMe));
router.post('/admin/change-password', requireAdmin, asyncHandler(changePassword));
router.post('/admin/create', requireAdmin, requireSuperAdmin, asyncHandler(createAdmin));

module.exports = router;
