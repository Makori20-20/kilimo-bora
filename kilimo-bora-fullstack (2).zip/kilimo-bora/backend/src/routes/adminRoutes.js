const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/authMiddleware');
const asyncHandler = require('../utils/asyncHandler');
const c = require('../controllers/adminController');

router.use(requireAdmin);

router.get('/crops', asyncHandler(c.listCrops));
router.post('/crops', asyncHandler(c.createCrop));
router.put('/crops/:id', asyncHandler(c.updateCrop));
router.delete('/crops/:id', asyncHandler(c.deleteCrop));

router.get('/prices', asyncHandler(c.listPrices));
router.post('/prices', asyncHandler(c.createPrice));
router.delete('/prices/:id', asyncHandler(c.deletePrice));

router.get('/pests', asyncHandler(c.listPests));
router.post('/pests', asyncHandler(c.createPest));
router.put('/pests/:id', asyncHandler(c.updatePest));
router.delete('/pests/:id', asyncHandler(c.deletePest));

router.get('/alerts', asyncHandler(c.listAlerts));
router.post('/alerts', asyncHandler(c.createAlert));
router.put('/alerts/:id/deactivate', asyncHandler(c.deactivateAlert));

router.get('/questions', asyncHandler(c.listQuestions));
router.put('/questions/:id/answer', asyncHandler(c.answerQuestion));

module.exports = router;
