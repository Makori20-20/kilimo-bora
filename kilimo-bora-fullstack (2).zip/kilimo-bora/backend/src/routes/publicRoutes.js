const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const asyncHandler = require('../utils/asyncHandler');

router.get('/crops', asyncHandler(async (req, res) => {
  const result = await pool.query('SELECT * FROM crops WHERE is_published = true ORDER BY name_en');
  res.json({ crops: result.rows });
}));

router.get('/prices', asyncHandler(async (req, res) => {
  const result = await pool.query(
    'SELECT * FROM market_prices ORDER BY price_date DESC, id DESC LIMIT 50'
  );
  res.json({ prices: result.rows });
}));

router.get('/pests', asyncHandler(async (req, res) => {
  const result = await pool.query('SELECT * FROM pests WHERE is_published = true ORDER BY updated_at DESC');
  res.json({ pests: result.rows });
}));

router.get('/alerts', asyncHandler(async (req, res) => {
  const result = await pool.query(
    `SELECT * FROM weather_alerts WHERE is_active = true
     AND (expires_at IS NULL OR expires_at > now()) ORDER BY created_at DESC`
  );
  res.json({ alerts: result.rows });
}));

router.post('/questions', asyncHandler(async (req, res) => {
  const { farmer_phone, question } = req.body;
  if (!question) return res.status(400).json({ error: 'question is required.' });
  const result = await pool.query(
    `INSERT INTO expert_questions (farmer_phone, question) VALUES ($1, $2) RETURNING *`,
    [farmer_phone || null, question]
  );
  res.status(201).json({ question: result.rows[0] });
}));

module.exports = router;
