-- Kilimo Bora Agricultural Information Hub — PostgreSQL schema

CREATE TABLE IF NOT EXISTS admins (
  id            SERIAL PRIMARY KEY,
  name          VARCHAR(120) NOT NULL,
  email         VARCHAR(160) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role          VARCHAR(20) NOT NULL DEFAULT 'admin' CHECK (role IN ('admin','superadmin')),
  is_active     BOOLEAN NOT NULL DEFAULT true,
  last_login_at TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS crops (
  id            SERIAL PRIMARY KEY,
  name_en       VARCHAR(120) NOT NULL,
  name_sw       VARCHAR(120) NOT NULL,
  name_ek       VARCHAR(120) NOT NULL,
  season        VARCHAR(120),
  advice_en     TEXT,
  advice_sw     TEXT,
  advice_ek     TEXT,
  is_published  BOOLEAN NOT NULL DEFAULT true,
  updated_by    INTEGER REFERENCES admins(id),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS market_prices (
  id            SERIAL PRIMARY KEY,
  crop_name     VARCHAR(120) NOT NULL,
  market        VARCHAR(120) NOT NULL,
  price         NUMERIC(10,2) NOT NULL,
  unit          VARCHAR(40) NOT NULL DEFAULT 'per kg',
  price_date    DATE NOT NULL DEFAULT CURRENT_DATE,
  updated_by    INTEGER REFERENCES admins(id),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS pests (
  id            SERIAL PRIMARY KEY,
  name          VARCHAR(150) NOT NULL,
  crop          VARCHAR(120) NOT NULL,
  severity      VARCHAR(20) NOT NULL CHECK (severity IN ('Wastani','Hatari Kubwa','Hatari Sana')),
  symptoms      TEXT NOT NULL,
  treatment     TEXT NOT NULL,
  prevention    TEXT,
  is_published  BOOLEAN NOT NULL DEFAULT true,
  updated_by    INTEGER REFERENCES admins(id),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS weather_alerts (
  id            SERIAL PRIMARY KEY,
  message       TEXT NOT NULL,
  severity      VARCHAR(20) NOT NULL DEFAULT 'info' CHECK (severity IN ('info','warning','danger')),
  is_active     BOOLEAN NOT NULL DEFAULT true,
  created_by    INTEGER REFERENCES admins(id),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at    TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS expert_questions (
  id            SERIAL PRIMARY KEY,
  farmer_phone  VARCHAR(20),
  question      TEXT NOT NULL,
  answer        TEXT,
  answered_by   INTEGER REFERENCES admins(id),
  status        VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','answered')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  answered_at   TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS admin_audit_log (
  id            SERIAL PRIMARY KEY,
  admin_id      INTEGER REFERENCES admins(id),
  action        VARCHAR(120) NOT NULL,
  details       JSONB,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_prices_crop ON market_prices(crop_name);
CREATE INDEX IF NOT EXISTS idx_prices_date ON market_prices(price_date);
CREATE INDEX IF NOT EXISTS idx_pests_crop ON pests(crop);
