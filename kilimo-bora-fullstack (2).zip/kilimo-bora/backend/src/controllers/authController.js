const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config/db');

function signToken(admin) {
  return jwt.sign(
    { sub: admin.id, email: admin.email, role: admin.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
  );
}

// POST /api/auth/admin/login
async function adminLogin(req, res) {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  try {
    const result = await pool.query('SELECT * FROM admins WHERE email = $1', [email.toLowerCase().trim()]);
    const admin = result.rows[0];

    // Deliberately generic error for both "no such user" and "wrong password"
    // so login attempts can't be used to enumerate valid admin emails.
    if (!admin || !admin.is_active) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const match = await bcrypt.compare(password, admin.password_hash);
    if (!match) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    await pool.query('UPDATE admins SET last_login_at = now() WHERE id = $1', [admin.id]);
    await pool.query(
      `INSERT INTO admin_audit_log (admin_id, action, details) VALUES ($1, 'login', $2)`,
      [admin.id, JSON.stringify({ ip: req.ip })]
    );

    const token = signToken(admin);
    return res.json({
      token,
      admin: { id: admin.id, name: admin.name, email: admin.email, role: admin.role },
    });
  } catch (err) {
    console.error('adminLogin error:', err.message);
    return res.status(500).json({ error: 'Internal server error.' });
  }
}

// GET /api/auth/admin/me
async function getMe(req, res) {
  return res.json({ admin: req.admin });
}

// POST /api/auth/admin/change-password
async function changePassword(req, res) {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: 'currentPassword and newPassword are required.' });
  }
  if (newPassword.length < 8) {
    return res.status(400).json({ error: 'New password must be at least 8 characters.' });
  }

  try {
    const result = await pool.query('SELECT * FROM admins WHERE id = $1', [req.admin.id]);
    const admin = result.rows[0];
    const match = await bcrypt.compare(currentPassword, admin.password_hash);
    if (!match) {
      return res.status(401).json({ error: 'Current password is incorrect.' });
    }
    const newHash = await bcrypt.hash(newPassword, 12);
    await pool.query('UPDATE admins SET password_hash = $1 WHERE id = $2', [newHash, admin.id]);
    await pool.query(
      `INSERT INTO admin_audit_log (admin_id, action) VALUES ($1, 'password_change')`,
      [admin.id]
    );
    return res.json({ message: 'Password updated successfully.' });
  } catch (err) {
    console.error('changePassword error:', err.message);
    return res.status(500).json({ error: 'Internal server error.' });
  }
}

// POST /api/auth/admin/create  (superadmin only — invites another admin)
async function createAdmin(req, res) {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'name, email, and password are required.' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  }
  const finalRole = role === 'superadmin' ? 'superadmin' : 'admin';

  try {
    const existing = await pool.query('SELECT id FROM admins WHERE email = $1', [email.toLowerCase().trim()]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'An admin with this email already exists.' });
    }
    const password_hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      `INSERT INTO admins (name, email, password_hash, role)
       VALUES ($1, $2, $3, $4) RETURNING id, name, email, role, created_at`,
      [name, email.toLowerCase().trim(), password_hash, finalRole]
    );
    await pool.query(
      `INSERT INTO admin_audit_log (admin_id, action, details) VALUES ($1, 'admin_created', $2)`,
      [req.admin.id, JSON.stringify({ createdEmail: email })]
    );
    return res.status(201).json({ admin: result.rows[0] });
  } catch (err) {
    console.error('createAdmin error:', err.message);
    return res.status(500).json({ error: 'Internal server error.' });
  }
}

module.exports = { adminLogin, getMe, changePassword, createAdmin };
