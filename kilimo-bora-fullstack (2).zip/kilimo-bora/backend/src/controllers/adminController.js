const pool = require('../config/db');

// Generic helpers to keep the CRUD controllers short and consistent.
async function logAction(adminId, action, details) {
  await pool.query(
    `INSERT INTO admin_audit_log (admin_id, action, details) VALUES ($1, $2, $3)`,
    [adminId, action, details ? JSON.stringify(details) : null]
  );
}

// ---------- CROPS ----------
async function listCrops(req, res) {
  const result = await pool.query('SELECT * FROM crops ORDER BY updated_at DESC');
  res.json({ crops: result.rows });
}

async function createCrop(req, res) {
  const { name_en, name_sw, name_ek, season, advice_en, advice_sw, advice_ek } = req.body;
  if (!name_en || !name_sw || !name_ek) {
    return res.status(400).json({ error: 'name_en, name_sw, and name_ek are required.' });
  }
  const result = await pool.query(
    `INSERT INTO crops (name_en, name_sw, name_ek, season, advice_en, advice_sw, advice_ek, updated_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [name_en, name_sw, name_ek, season || null, advice_en || null, advice_sw || null, advice_ek || null, req.admin.id]
  );
  await logAction(req.admin.id, 'crop_created', { id: result.rows[0].id });
  res.status(201).json({ crop: result.rows[0] });
}

async function updateCrop(req, res) {
  const { id } = req.params;
  const { name_en, name_sw, name_ek, season, advice_en, advice_sw, advice_ek, is_published } = req.body;
  const result = await pool.query(
    `UPDATE crops SET name_en=$1, name_sw=$2, name_ek=$3, season=$4, advice_en=$5,
       advice_sw=$6, advice_ek=$7, is_published=COALESCE($8, is_published),
       updated_by=$9, updated_at=now()
     WHERE id=$10 RETURNING *`,
    [name_en, name_sw, name_ek, season, advice_en, advice_sw, advice_ek, is_published, req.admin.id, id]
  );
  if (!result.rows[0]) return res.status(404).json({ error: 'Crop not found.' });
  await logAction(req.admin.id, 'crop_updated', { id });
  res.json({ crop: result.rows[0] });
}

async function deleteCrop(req, res) {
  const { id } = req.params;
  await pool.query('DELETE FROM crops WHERE id = $1', [id]);
  await logAction(req.admin.id, 'crop_deleted', { id });
  res.json({ message: 'Crop deleted.' });
}

// ---------- MARKET PRICES ----------
async function listPrices(req, res) {
  const result = await pool.query('SELECT * FROM market_prices ORDER BY price_date DESC, id DESC LIMIT 200');
  res.json({ prices: result.rows });
}

async function createPrice(req, res) {
  const { crop_name, market, price, unit, price_date } = req.body;
  if (!crop_name || !market || price == null) {
    return res.status(400).json({ error: 'crop_name, market, and price are required.' });
  }
  const result = await pool.query(
    `INSERT INTO market_prices (crop_name, market, price, unit, price_date, updated_by)
     VALUES ($1,$2,$3,COALESCE($4,'per kg'),COALESCE($5, CURRENT_DATE),$6) RETURNING *`,
    [crop_name, market, price, unit, price_date, req.admin.id]
  );
  await logAction(req.admin.id, 'price_created', { id: result.rows[0].id });
  res.status(201).json({ price: result.rows[0] });
}

async function deletePrice(req, res) {
  const { id } = req.params;
  await pool.query('DELETE FROM market_prices WHERE id = $1', [id]);
  await logAction(req.admin.id, 'price_deleted', { id });
  res.json({ message: 'Price entry deleted.' });
}

// ---------- PESTS ----------
async function listPests(req, res) {
  const result = await pool.query('SELECT * FROM pests ORDER BY updated_at DESC');
  res.json({ pests: result.rows });
}

async function createPest(req, res) {
  const { name, crop, severity, symptoms, treatment, prevention } = req.body;
  if (!name || !crop || !severity || !symptoms || !treatment) {
    return res.status(400).json({ error: 'name, crop, severity, symptoms, and treatment are required.' });
  }
  const result = await pool.query(
    `INSERT INTO pests (name, crop, severity, symptoms, treatment, prevention, updated_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [name, crop, severity, symptoms, treatment, prevention || null, req.admin.id]
  );
  await logAction(req.admin.id, 'pest_created', { id: result.rows[0].id });
  res.status(201).json({ pest: result.rows[0] });
}

async function updatePest(req, res) {
  const { id } = req.params;
  const { name, crop, severity, symptoms, treatment, prevention, is_published } = req.body;
  const result = await pool.query(
    `UPDATE pests SET name=$1, crop=$2, severity=$3, symptoms=$4, treatment=$5,
       prevention=$6, is_published=COALESCE($7, is_published), updated_by=$8, updated_at=now()
     WHERE id=$9 RETURNING *`,
    [name, crop, severity, symptoms, treatment, prevention, is_published, req.admin.id, id]
  );
  if (!result.rows[0]) return res.status(404).json({ error: 'Pest entry not found.' });
  await logAction(req.admin.id, 'pest_updated', { id });
  res.json({ pest: result.rows[0] });
}

async function deletePest(req, res) {
  const { id } = req.params;
  await pool.query('DELETE FROM pests WHERE id = $1', [id]);
  await logAction(req.admin.id, 'pest_deleted', { id });
  res.json({ message: 'Pest entry deleted.' });
}

// ---------- WEATHER ALERTS ----------
async function listAlerts(req, res) {
  const result = await pool.query('SELECT * FROM weather_alerts ORDER BY created_at DESC');
  res.json({ alerts: result.rows });
}

async function createAlert(req, res) {
  const { message, severity, expires_at } = req.body;
  if (!message) return res.status(400).json({ error: 'message is required.' });
  const result = await pool.query(
    `INSERT INTO weather_alerts (message, severity, expires_at, created_by)
     VALUES ($1, COALESCE($2,'info'), $3, $4) RETURNING *`,
    [message, severity, expires_at || null, req.admin.id]
  );
  await logAction(req.admin.id, 'alert_created', { id: result.rows[0].id });
  res.status(201).json({ alert: result.rows[0] });
}

async function deactivateAlert(req, res) {
  const { id } = req.params;
  await pool.query('UPDATE weather_alerts SET is_active = false WHERE id = $1', [id]);
  await logAction(req.admin.id, 'alert_deactivated', { id });
  res.json({ message: 'Alert deactivated.' });
}

// ---------- EXPERT QUESTIONS (moderation queue) ----------
async function listQuestions(req, res) {
  const status = req.query.status;
  const result = status
    ? await pool.query('SELECT * FROM expert_questions WHERE status = $1 ORDER BY created_at DESC', [status])
    : await pool.query('SELECT * FROM expert_questions ORDER BY created_at DESC');
  res.json({ questions: result.rows });
}

async function answerQuestion(req, res) {
  const { id } = req.params;
  const { answer } = req.body;
  if (!answer) return res.status(400).json({ error: 'answer is required.' });
  const result = await pool.query(
    `UPDATE expert_questions SET answer=$1, status='answered', answered_by=$2, answered_at=now()
     WHERE id=$3 RETURNING *`,
    [answer, req.admin.id, id]
  );
  if (!result.rows[0]) return res.status(404).json({ error: 'Question not found.' });
  await logAction(req.admin.id, 'question_answered', { id });
  res.json({ question: result.rows[0] });
}

module.exports = {
  listCrops, createCrop, updateCrop, deleteCrop,
  listPrices, createPrice, deletePrice,
  listPests, createPest, updatePest, deletePest,
  listAlerts, createAlert, deactivateAlert,
  listQuestions, answerQuestion,
};
